
package javaapplication1;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.sql.Statement;
import java.sql.ResultSet;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JButton;        

public class LR extends javax.swing.JFrame {

    java.sql.Connection conn = null;
    ResultSet rs = null;
    Statement st;
    
    public LR() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        label4 = new java.awt.Label();
        label5 = new java.awt.Label();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 153));
        setMinimumSize(new java.awt.Dimension(280, 240));
        setSize(new java.awt.Dimension(400, 400));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField1.setToolTipText("");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 150, -1));
        jTextField1.getAccessibleContext().setAccessibleName("");

        getContentPane().add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 130, 150, -1));
        jPasswordField1.getAccessibleContext().setAccessibleName("pfield1");

        label1.setText("ID:");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));

        label2.setText("Password:");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, -1, -1));

        jButton3.setText("Login");
        jButton3.setMaximumSize(new java.awt.Dimension(60, 30));
        jButton3.setMinimumSize(new java.awt.Dimension(60, 30));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, -1, -1));

        jButton4.setText("Exit");
        jButton4.setMaximumSize(new java.awt.Dimension(60, 30));
        jButton4.setMinimumSize(new java.awt.Dimension(60, 30));
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 190, -1, -1));

        label4.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        label4.setText("Money is Money");
        getContentPane().add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 260, -1, -1));

        label5.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label5.setText("Welcome to MVD Bank");
        getContentPane().add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        String username = jTextField1.getText();
        String password = jPasswordField1.getText();
        
        try{
            
            int log = 1;
            //Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test" ,"root","1234");
            st = (Statement)conn.createStatement();
            rs = st.executeQuery("select * from customer");
           
            while(rs.next()){
                if(rs.getString(1).equals(username) && rs.getString(2).equals(password)){
                    TempData.Cnum = username;        
                    log = 0;
                    break;
                }

            }
            if(log == 0){
                this.hide();
                SAcc sac = new SAcc();
                sac.setVisible(true);

            }

            else{
                JOptionPane.showMessageDialog(null,"Connection failed","Login System",JOptionPane.ERROR_MESSAGE);
                jTextField1.setText("");
                jPasswordField1.setText("");
                jTextField1.grabFocus();
            }
        }

        catch(SQLException ex){
            System.err.println(ex);
        }
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        System.exit(0);
            
    }//GEN-LAST:event_jButton4MouseClicked
  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[])throws Exception {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LR().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label4;
    private java.awt.Label label5;
    // End of variables declaration//GEN-END:variables

}
