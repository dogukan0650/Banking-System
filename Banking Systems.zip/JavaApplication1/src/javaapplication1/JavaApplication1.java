
package javaapplication1;

public class JavaApplication1 {

    public static void main(String[] args) {
        // TODO code application logic here
        LR enter = new LR();
        enter.setVisible(true);
    }
    
}


