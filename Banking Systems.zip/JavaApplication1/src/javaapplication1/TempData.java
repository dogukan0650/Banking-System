
package javaapplication1;
public class TempData {

    static String Cnum;
    static String Acnum;
    static String Balnc;
  
}
