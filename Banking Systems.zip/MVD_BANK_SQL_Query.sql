-- Creating tables
create table customer (
Cnumber integer,
pword integer,
Fname varchar(30),
Lname varchar(30),
SSN integer
);
Create table Account(
Cnumber integer,
Anumber integer,
Balance integer,
Interest integer,
Credit_Limit integer,
Primary Key (Anumber),
Foreign key (Cnumber) references customer(Cnumber)
);
create table transaction (
Cnumber integer ,
Anumber integer,
Sendmoney integer ,
Recievemoney integer,
Paybill integer,
Foreign key (Cnumber) references customer(Cnumber),
Foreign KEY (Anumber) references account (Anumber),
time date 
);
-- to make app work properly
SET GLOBAL time_zone = '+3:00';

-- inserting data into customer 
INSERT INTO customer
values (123 , 1234,"admin","admin");
INSERT INTO customer
values (170444008 , 1 ,"Mahir","Sahin");
INSERT INTO customer
values (170444004 , 2 ,"Safa","Ozcan");
INSERT INTO customer
values (170444002 , 3,"Dogukan","Karacam" );
-- instering both credit and bank account 
INSERT INTO account
values(123,1234,1000,16,null);
INSERT INTO account
values(123,12345,null,null,15000);

INSERT INTO account
values(170444008,1704440081,400000,16,null);
INSERT INTO account
values(170444008,1704440082,null,null,10000);

INSERT INTO account
values(170444004,1704440041,36783,16,null);
INSERT INTO account
values(170444004,1704440042,null,null,1500);

INSERT INTO account
values(170444002,1704440021,2500,16,null);
INSERT INTO account
values(170444002,1704440022,null,null,5000);